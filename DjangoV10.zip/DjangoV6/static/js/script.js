// Define the function to display a message
function displayMessage() {
    alert('Button n1 was clicked!');
}

// Attach the function to the button's click event
document.getElementById('n1').addEventListener('click', displayMessage);
